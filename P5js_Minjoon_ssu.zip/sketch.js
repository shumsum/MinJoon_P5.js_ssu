<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>p5.js 작품 모음</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>나의 p5.js 작품</h1>
        <p>아래 링크를 클릭하여 다양한 p5.js 프로그램을 감상하세요.</p>
    </header>

    <section id="projects">
    
        <div class="project">
            <a href="sample1/index.html">
                프로젝트 1: 이 프로그램은 마우스를 따라 움직이는 원을 그립니다.
            </a>
        </div>
    
        <div class="project">
            <a href="sample2/index.html">
                프로젝트 2: 이 프로그램은 다양한 색상으로 변화하는 배경을 만듭니다.
            </a>
        </div>

    </section>
</body>
</html>